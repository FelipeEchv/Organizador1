import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactoService {

  private apiURL = 'http://192.168.100.9:3000/contactos';

  constructor(private http: HttpClient) { }

  // Obtener todos los contactos
  getContactos(): Observable<any[]> {
    return this.http.get<any[]>(this.apiURL);
  }

  // Agregar un nuevo contacto
  agregarContacto(contacto: any): Observable<any> {
    return this.http.post(this.apiURL, contacto);
  }

  // Editar un contacto existente
  editarContacto(id: number, contacto: any): Observable<any> {
    return this.http.put(`${this.apiURL}/${id}`, contacto);
  }

  // Eliminar un contacto
  eliminarContacto(id: number): Observable<any> {
    return this.http.delete(`${this.apiURL}/${id}`);
  }
}
